<div align="center">
    <img src="src/assets/logo512.png" alt="Logo Resep Kita" width="200">
    <h1>Selamat Datang di Resep Masakan</h1>
    <p>Temukan petualangan rasa melalui resep-resep kuliner terbaik di dunia!</p>
    <a href="https://cheskoweb.site"><strong>🌐 Kunjungi Kami</strong></a>
    <br>
    <br>
    <a href="https://cheskoweb.site">
        <img src="src/assets/resep1.png" alt="Tampilan Resep Masakan" width="800">
    </a>
    <br>
    <br>
</div>

## 🍔 Kenikmatan Kuliner Menanti

Nikmati koleksi resep kami yang beragam, mulai dari makanan sehat, hidangan cepat saji, hingga kuliner mewah. Setiap resep dilengkapi dengan panduan langkah demi langkah yang mudah diikuti.

## 🍴 Daftar dan Buat Resep 

Kunjungi [Resep Kita](https://cheskoweb.site) untuk memulai petualangan kuliner Anda. Tersedia pula fitur pencarian untuk mencari resep spesifik sesuai keinginan.
## 📞 Hubungi Kami

Jika Anda memiliki pertanyaan, ide resep, atau ingin sekadar menyapa, hubungi kami di [afiq1you@gmail.com](mailto:afiq1you@gmail.com).

Selamat berselancar di dunia rasa di [Resep Masakan](https://cheskoweb.site)! 🍽️👨‍🍳
